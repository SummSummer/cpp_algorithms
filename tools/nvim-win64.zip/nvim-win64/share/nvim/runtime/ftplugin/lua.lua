if vim.g.ts_highlight_lua then
  vim.treesitter.start()
end
